package com.example.cloud.domain.services;

import com.example.cloud.domain.entities.Resource;
import com.example.cloud.domain.repositories.ResourceRepository;

import java.util.List;

public class ResourceService {
    private final ResourceRepository resourceRepository;

    public ResourceService(ResourceRepository resourceRepository) {
        this.resourceRepository = resourceRepository;
    }

    public void addResource(Resource resource) {
        resourceRepository.save(resource);
    }

    public Resource getResource(String id) {
        return resourceRepository.findById(id);
    }

    public List<Resource> getAllResources() {
        return resourceRepository.findAll();
    }

    public void deleteResource(String id) {
        resourceRepository.delete(id);
    }
}