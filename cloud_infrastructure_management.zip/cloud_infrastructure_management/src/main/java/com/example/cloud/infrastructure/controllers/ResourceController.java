package com.example.cloud.infrastructure.controllers;

import com.example.cloud.domain.usecases.ManageResource;
import com.example.cloud.domain.entities.Resource;

import java.util.List;

public class ResourceController {
    private final ManageResource manageResource;

    public ResourceController(ManageResource manageResource) {
        this.manageResource = manageResource;
    }

    public void addResource(String id, String name, String type, String status) {
        manageResource.createResource(id, name, type, status);
    }

    public Resource getResource(String id) {
        return manageResource.viewResource(id);
    }

    public List<Resource> getAllResources() {
        return manageResource.viewAllResources();
    }

    public void deleteResource(String id) {
        manageResource.removeResource(id);
    }
}