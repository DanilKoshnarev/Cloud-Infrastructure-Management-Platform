package com.example.cloud.domain.entities;

public class Resource {
    private String id;
    private String name;
    private String type;
    private String status;

    public Resource(String id, String name, String type, String status) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.status = status;
    }

    // Getters and Setters
}