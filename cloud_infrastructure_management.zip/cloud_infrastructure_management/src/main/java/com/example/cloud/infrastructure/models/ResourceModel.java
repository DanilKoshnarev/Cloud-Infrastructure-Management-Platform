package com.example.cloud.infrastructure.models;

import com.example.cloud.domain.entities.Resource;
import com.example.cloud.domain.repositories.ResourceRepository;

import java.util.ArrayList;
import java.util.List;

public class ResourceModel implements ResourceRepository {
    private final List<Resource> resources = new ArrayList<>();

    @Override
    public void save(Resource resource) {
        resources.add(resource);
    }

    @Override
    public Resource findById(String id) {
        return resources.stream().filter(resource -> resource.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<Resource> findAll() {
        return new ArrayList<>(resources);
    }

    @Override
    public void delete(String id) {
        resources.removeIf(resource -> resource.getId().equals(id));
    }
}