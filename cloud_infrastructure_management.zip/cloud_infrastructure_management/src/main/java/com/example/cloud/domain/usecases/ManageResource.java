package com.example.cloud.domain.usecases;

import com.example.cloud.domain.entities.Resource;
import com.example.cloud.domain.services.ResourceService;

import java.util.List;

public class ManageResource {
    private final ResourceService resourceService;

    public ManageResource(ResourceService resourceService) {
        this.resourceService = resourceService;
    }

    public void createResource(String id, String name, String type, String status) {
        Resource resource = new Resource(id, name, type, status);
        resourceService.addResource(resource);
    }

    public Resource viewResource(String id) {
        return resourceService.getResource(id);
    }

    public List<Resource> viewAllResources() {
        return resourceService.getAllResources();
    }

    public void removeResource(String id) {
        resourceService.deleteResource(id);
    }
}