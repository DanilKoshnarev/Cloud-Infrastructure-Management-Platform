package com.example.cloud.domain.repositories;

import com.example.cloud.domain.entities.Resource;

import java.util.List;

public interface ResourceRepository {
    void save(Resource resource);
    Resource findById(String id);
    List<Resource> findAll();
    void delete(String id);
}