package com.example.cloud.domain.entities;

import java.util.Date;

public class Deployment {
    private String id;
    private String resourceId;
    private Date deploymentDate;
    private String version;

    public Deployment(String id, String resourceId, Date deploymentDate, String version) {
        this.id = id;
        this.resourceId = resourceId;
        this.deploymentDate = deploymentDate;
        this.version = version;
    }

    // Getters and Setters
}