package com.example.cloud;

import com.example.cloud.domain.entities.Resource;
import com.example.cloud.domain.repositories.ResourceRepository;
import com.example.cloud.domain.services.ResourceService;
import com.example.cloud.domain.usecases.ManageResource;
import com.example.cloud.infrastructure.models.ResourceModel;
import com.example.cloud.infrastructure.controllers.ResourceController;

public class Application {
    public static void main(String[] args) {
        ResourceRepository resourceRepository = new ResourceModel();
        ResourceService resourceService = new ResourceService(resourceRepository);
        ManageResource manageResource = new ManageResource(resourceService);
        ResourceController resourceController = new ResourceController(manageResource);

        // Add resources
        resourceController.addResource("1", "Compute Instance", "VM", "Running");
        resourceController.addResource("2", "Storage Bucket", "Storage", "Available");

        // View all resources
        for (Resource resource : resourceController.getAllResources()) {
            System.out.println("ID: " + resource.getId() + ", Name: " + resource.getName() + ", Type: " + resource.getType() + ", Status: " + resource.getStatus());
        }

        
        resourceController.deleteResource("1");

        
        for (Resource resource : resourceController.getAllResources()) {
            System.out.println("ID: " + resource.getId() + ", Name: " + resource.getName() + ", Type: " + resource.getType() + ", Status: " + resource.getStatus());
        }
    }
}